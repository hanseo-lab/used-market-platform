package com.kh.board.enums;

public enum ProductStatus {
    FOR_SALE, //판매중
    RESERVED, //예약중
    SOLD_OUT //판매완료
}
